public class MoPubStaticNativeAd : AbstractNativeAd
{
}
