using System.Collections.Generic;
using UnityEngine;

public class MoPubDemoGUI : MonoBehaviour
{
	private readonly Dictionary<string, bool> _adUnitToLoadedMapping = new Dictionary<string, bool>();

	private readonly Dictionary<string, bool> _adUnitToShownMapping = new Dictionary<string, bool>();

	private readonly Dictionary<string, List<MoPubBase.Reward>> _adUnitToRewardsMapping = new Dictionary<string, List<MoPubBase.Reward>>();

	private bool _consentDialogLoaded;

	private readonly string[] _bannerAdUnits = new string[1]
	{
		"b195f8dd8ded45fe847ad89ed1d016da"
	};

	private readonly string[] _interstitialAdUnits = new string[1]
	{
		"24534e1901884e398f1253216226017e"
	};

	private readonly string[] _rewardedVideoAdUnits = new string[1]
	{
		"920b6145fb1546cf8b5cf2ac34638bb7"
	};

	private readonly string[] _rewardedRichMediaAdUnits = new string[1]
	{
		"a96ae2ef41d44822af45c6328c4e1eb1"
	};

	[SerializeField]
	private GUISkin _skin;

	private GUIStyle _smallerFont;

	private int _sectionMarginSize;

	private GUIStyle _centeredStyle;

	private static string _customDataDefaultText = "Optional custom data";

	private string _rvCustomData = _customDataDefaultText;

	private string _rrmCustomData = _customDataDefaultText;

	private bool _canCollectPersonalInfo;

	private MoPubBase.Consent.Status _currentConsentStatus;

	private bool _shouldShowConsentDialog;

	private bool? _isGdprApplicable = false;

	private bool _isGdprForced;

	private string _status = string.Empty;

	public bool ConsentDialogLoaded
	{
		private get
		{
			return _consentDialogLoaded;
		}
		set
		{
			_consentDialogLoaded = value;
			if (_consentDialogLoaded)
			{
				UpdateStatusLabel("Consent dialog loaded");
			}
		}
	}

	private static bool IsAdUnitArrayNullOrEmpty(ICollection<string> adUnitArray)
	{
		return adUnitArray == null || adUnitArray.Count == 0;
	}

	private void AddAdUnitsToStateMaps(IEnumerable<string> adUnits)
	{
		foreach (string adUnit in adUnits)
		{
			_adUnitToLoadedMapping[adUnit] = false;
			_adUnitToShownMapping[adUnit] = false;
		}
	}

	public void SdkInitialized()
	{
		UpdateConsentValues();
	}

	public void UpdateStatusLabel(string message)
	{
		_status = message;
	}

	public void ClearStatusLabel()
	{
		UpdateStatusLabel(string.Empty);
	}

	public void ConsentStatusChanged(MoPubBase.Consent.Status newStatus, bool canCollectPersonalInfo)
	{
		_canCollectPersonalInfo = canCollectPersonalInfo;
		_currentConsentStatus = newStatus;
		_shouldShowConsentDialog = MoPubAndroid.ShouldShowConsentDialog;
		UpdateStatusLabel("Consent status changed");
	}

	public void LoadAvailableRewards(string adUnitId, List<MoPubBase.Reward> availableRewards)
	{
		_adUnitToRewardsMapping.Remove(adUnitId);
		if (availableRewards != null)
		{
			_adUnitToRewardsMapping[adUnitId] = availableRewards;
		}
	}

	public void BannerLoaded(string adUnitId, float height)
	{
		AdLoaded(adUnitId);
		_adUnitToShownMapping[adUnitId] = true;
	}

	public void AdLoaded(string adUnit)
	{
		_adUnitToLoadedMapping[adUnit] = true;
		UpdateStatusLabel("Loaded " + adUnit);
	}

	public void AdDismissed(string adUnit)
	{
		_adUnitToLoadedMapping[adUnit] = false;
		ClearStatusLabel();
	}

	private void Awake()
	{
		if (Screen.width < 960 && Screen.height < 960)
		{
			_skin.button.fixedHeight = 50f;
		}
		_smallerFont = new GUIStyle(_skin.label)
		{
			fontSize = _skin.button.fontSize
		};
		_centeredStyle = new GUIStyle(_skin.label)
		{
			alignment = TextAnchor.UpperCenter
		};
		_sectionMarginSize = _skin.label.fontSize;
		AddAdUnitsToStateMaps(_bannerAdUnits);
		AddAdUnitsToStateMaps(_interstitialAdUnits);
		AddAdUnitsToStateMaps(_rewardedVideoAdUnits);
		AddAdUnitsToStateMaps(_rewardedRichMediaAdUnits);
		ConsentDialogLoaded = false;
	}

	private void Start()
	{
		string adUnitId = _bannerAdUnits[0];
		MoPubBase.SdkConfiguration sdkConfiguration = default(MoPubBase.SdkConfiguration);
		sdkConfiguration.AdUnitId = adUnitId;
		sdkConfiguration.LogLevel = MoPubBase.LogLevel.MPLogLevelDebug;
		sdkConfiguration.MediatedNetworks = new MoPubBase.MediatedNetwork[0];
		MoPubAndroid.InitializeSdk(sdkConfiguration);
		MoPubAndroid.LoadBannerPluginsForAdUnits(_bannerAdUnits);
		MoPubAndroid.LoadInterstitialPluginsForAdUnits(_interstitialAdUnits);
		MoPubAndroid.LoadRewardedVideoPluginsForAdUnits(_rewardedVideoAdUnits);
		MoPubAndroid.LoadRewardedVideoPluginsForAdUnits(_rewardedRichMediaAdUnits);
		GameObject gameObject = GameObject.Find("MoPubNativeAds");
		if (gameObject != null)
		{
			gameObject.SetActive(value: false);
		}
	}

	private void OnGUI()
	{
		GUI.skin = _skin;
		Rect safeArea = Screen.safeArea;
		safeArea.x += 20f;
		safeArea.width -= 40f;
		GUILayout.BeginArea(safeArea);
		CreateTitleSection();
		CreateBannersSection();
		CreateInterstitialsSection();
		CreateRewardedVideosSection();
		CreateRewardedRichMediaSection();
		CreateUserConsentSection();
		CreateActionsSection();
		CreateStatusSection();
		GUILayout.EndArea();
	}

	private void CreateTitleSection()
	{
		int fontSize = _centeredStyle.fontSize;
		_centeredStyle.fontSize = 48;
		GUI.Label(new Rect(0f, 10f, Screen.width, 60f), MoPubBase.PluginName, _centeredStyle);
		_centeredStyle.fontSize = fontSize;
		GUI.Label(new Rect(0f, 70f, Screen.width, 60f), "with " + MoPub.SdkName, _centeredStyle);
	}

	private void CreateBannersSection()
	{
		GUILayout.Space(102f);
		GUILayout.Label("Banners");
		if (!IsAdUnitArrayNullOrEmpty(_bannerAdUnits))
		{
			string[] bannerAdUnits = _bannerAdUnits;
			foreach (string text in bannerAdUnits)
			{
				GUILayout.BeginHorizontal();
				GUI.enabled = !_adUnitToLoadedMapping[text];
				if (GUILayout.Button(CreateRequestButtonLabel(text)))
				{
					UnityEngine.Debug.Log("requesting banner with AdUnit: " + text);
					UpdateStatusLabel("Requesting " + text);
					MoPubAndroid.CreateBanner(text, MoPubBase.AdPosition.BottomCenter);
				}
				GUI.enabled = _adUnitToLoadedMapping[text];
				if (GUILayout.Button("Destroy"))
				{
					ClearStatusLabel();
					MoPubAndroid.DestroyBanner(text);
					_adUnitToLoadedMapping[text] = false;
					_adUnitToShownMapping[text] = false;
				}
				GUI.enabled = (_adUnitToLoadedMapping[text] && !_adUnitToShownMapping[text]);
				if (GUILayout.Button("Show"))
				{
					ClearStatusLabel();
					MoPubAndroid.ShowBanner(text, shouldShow: true);
					_adUnitToShownMapping[text] = true;
				}
				GUI.enabled = (_adUnitToLoadedMapping[text] && _adUnitToShownMapping[text]);
				if (GUILayout.Button("Hide"))
				{
					ClearStatusLabel();
					MoPubAndroid.ShowBanner(text, shouldShow: false);
					_adUnitToShownMapping[text] = false;
				}
				GUI.enabled = true;
				GUILayout.EndHorizontal();
			}
		}
		else
		{
			GUILayout.Label("No banner AdUnits available", _smallerFont, (GUILayoutOption[])null);
		}
	}

	private void CreateInterstitialsSection()
	{
		GUILayout.Space(_sectionMarginSize);
		GUILayout.Label("Interstitials");
		if (!IsAdUnitArrayNullOrEmpty(_interstitialAdUnits))
		{
			string[] interstitialAdUnits = _interstitialAdUnits;
			foreach (string text in interstitialAdUnits)
			{
				GUILayout.BeginHorizontal();
				GUI.enabled = !_adUnitToLoadedMapping[text];
				if (GUILayout.Button(CreateRequestButtonLabel(text)))
				{
					UnityEngine.Debug.Log("requesting interstitial with AdUnit: " + text);
					UpdateStatusLabel("Requesting " + text);
					MoPubAndroid.RequestInterstitialAd(text, string.Empty, string.Empty);
				}
				GUI.enabled = _adUnitToLoadedMapping[text];
				if (GUILayout.Button("Show"))
				{
					ClearStatusLabel();
					MoPubAndroid.ShowInterstitialAd(text);
				}
				GUI.enabled = true;
				GUILayout.EndHorizontal();
			}
		}
		else
		{
			GUILayout.Label("No interstitial AdUnits available", _smallerFont, (GUILayoutOption[])null);
		}
	}

	private void CreateRewardedVideosSection()
	{
		GUILayout.Space(_sectionMarginSize);
		GUILayout.Label("Rewarded Videos");
		if (!IsAdUnitArrayNullOrEmpty(_rewardedVideoAdUnits))
		{
			CreateCustomDataField("rvCustomDataField", ref _rvCustomData);
			string[] rewardedVideoAdUnits = _rewardedVideoAdUnits;
			foreach (string text in rewardedVideoAdUnits)
			{
				GUILayout.BeginHorizontal();
				GUI.enabled = !_adUnitToLoadedMapping[text];
				if (GUILayout.Button(CreateRequestButtonLabel(text)))
				{
					UnityEngine.Debug.Log("requesting rewarded video with AdUnit: " + text);
					UpdateStatusLabel("Requesting " + text);
					MoPubAndroid.RequestRewardedVideo(text, null, "rewarded, video, mopub", null, 37.7833, 122.4167, "customer101");
				}
				GUI.enabled = _adUnitToLoadedMapping[text];
				if (GUILayout.Button("Show"))
				{
					ClearStatusLabel();
					MoPubAndroid.ShowRewardedVideo(text, GetCustomData(_rvCustomData));
				}
				GUI.enabled = true;
				GUILayout.EndHorizontal();
				if (MoPubAndroid.HasRewardedVideo(text) && _adUnitToRewardsMapping.ContainsKey(text) && _adUnitToRewardsMapping[text].Count > 1)
				{
					GUILayout.BeginVertical();
					GUILayout.Space(_sectionMarginSize);
					GUILayout.Label("Select a reward:");
					foreach (MoPubBase.Reward item in _adUnitToRewardsMapping[text])
					{
						if (GUILayout.Button(item.ToString()))
						{
							MoPubAndroid.SelectReward(text, item);
						}
					}
					GUILayout.Space(_sectionMarginSize);
					GUILayout.EndVertical();
				}
			}
		}
		else
		{
			GUILayout.Label("No rewarded video AdUnits available", _smallerFont, (GUILayoutOption[])null);
		}
	}

	private void CreateRewardedRichMediaSection()
	{
		GUILayout.Space(_sectionMarginSize);
		GUILayout.Label("Rewarded Rich Media");
		if (!IsAdUnitArrayNullOrEmpty(_rewardedRichMediaAdUnits))
		{
			CreateCustomDataField("rrmCustomDataField", ref _rrmCustomData);
			string[] rewardedRichMediaAdUnits = _rewardedRichMediaAdUnits;
			foreach (string text in rewardedRichMediaAdUnits)
			{
				GUILayout.BeginHorizontal();
				GUI.enabled = !_adUnitToLoadedMapping[text];
				if (GUILayout.Button(CreateRequestButtonLabel(text)))
				{
					UnityEngine.Debug.Log("requesting rewarded rich media with AdUnit: " + text);
					UpdateStatusLabel("Requesting " + text);
					MoPubAndroid.RequestRewardedVideo(text, null, "rewarded, video, mopub", null, 37.7833, 122.4167, "customer101");
				}
				GUI.enabled = _adUnitToLoadedMapping[text];
				if (GUILayout.Button("Show"))
				{
					ClearStatusLabel();
					MoPubAndroid.ShowRewardedVideo(text, GetCustomData(_rrmCustomData));
				}
				GUI.enabled = true;
				GUILayout.EndHorizontal();
				if (MoPubAndroid.HasRewardedVideo(text) && _adUnitToRewardsMapping.ContainsKey(text) && _adUnitToRewardsMapping[text].Count > 1)
				{
					GUILayout.BeginVertical();
					GUILayout.Space(_sectionMarginSize);
					GUILayout.Label("Select a reward:");
					foreach (MoPubBase.Reward item in _adUnitToRewardsMapping[text])
					{
						if (GUILayout.Button(item.ToString()))
						{
							MoPubAndroid.SelectReward(text, item);
						}
					}
					GUILayout.Space(_sectionMarginSize);
					GUILayout.EndVertical();
				}
			}
		}
		else
		{
			GUILayout.Label("No rewarded rich media AdUnits available", _smallerFont, (GUILayoutOption[])null);
		}
	}

	private void CreateUserConsentSection()
	{
		GUILayout.Space(_sectionMarginSize);
		GUILayout.Label("User Consent");
		GUILayout.Label("Can collect personally identifiable information: " + _canCollectPersonalInfo, _smallerFont);
		GUILayout.Label("Current consent status: " + _currentConsentStatus, _smallerFont);
		GUILayout.Label("Should show consent dialog: " + _shouldShowConsentDialog, _smallerFont);
		bool? isGdprApplicable = _isGdprApplicable;
		GUILayout.Label("Is GDPR applicable: " + ((!isGdprApplicable.HasValue) ? "Unknown" : _isGdprApplicable.ToString()), _smallerFont);
		GUILayout.BeginHorizontal();
		GUI.enabled = !ConsentDialogLoaded;
		if (GUILayout.Button("Load Consent Dialog"))
		{
			UpdateStatusLabel("Loading consent dialog");
			MoPubAndroid.LoadConsentDialog();
		}
		GUI.enabled = ConsentDialogLoaded;
		if (GUILayout.Button("Show Consent Dialog"))
		{
			ClearStatusLabel();
			MoPubAndroid.ShowConsentDialog();
		}
		GUI.enabled = !_isGdprForced;
		if (GUILayout.Button("Force GDPR"))
		{
			ClearStatusLabel();
			MoPubAndroid.ForceGdprApplicable();
			UpdateConsentValues();
			_isGdprForced = true;
		}
		GUI.enabled = true;
		if (GUILayout.Button("Grant Consent"))
		{
			MoPubAndroid.PartnerApi.GrantConsent();
		}
		if (GUILayout.Button("Revoke Consent"))
		{
			MoPubAndroid.PartnerApi.RevokeConsent();
		}
		GUI.enabled = true;
		GUILayout.EndHorizontal();
	}

	private void CreateActionsSection()
	{
		GUILayout.Space(_sectionMarginSize);
		GUILayout.Label("Actions");
		if (GUILayout.Button("Report App Open"))
		{
			ClearStatusLabel();
			MoPubAndroid.ReportApplicationOpen();
		}
		if (GUILayout.Button("Enable Location Support"))
		{
			ClearStatusLabel();
			MoPubAndroid.EnableLocationSupport(shouldUseLocation: true);
		}
	}

	private void UpdateConsentValues()
	{
		_canCollectPersonalInfo = MoPubAndroid.CanCollectPersonalInfo;
		_currentConsentStatus = MoPubAndroid.CurrentConsentStatus;
		_shouldShowConsentDialog = MoPubAndroid.ShouldShowConsentDialog;
		_isGdprApplicable = MoPubAndroid.IsGdprApplicable;
	}

	private static void CreateCustomDataField(string fieldName, ref string customDataValue)
	{
		GUI.SetNextControlName(fieldName);
		customDataValue = GUILayout.TextField(customDataValue, GUILayout.MinWidth(200f));
		if (Event.current.type == EventType.Repaint)
		{
			if (GUI.GetNameOfFocusedControl() == fieldName && customDataValue == _customDataDefaultText)
			{
				customDataValue = string.Empty;
			}
			else if (GUI.GetNameOfFocusedControl() != fieldName && string.IsNullOrEmpty(customDataValue))
			{
				customDataValue = _customDataDefaultText;
			}
		}
	}

	private void CreateStatusSection()
	{
		GUILayout.Space(40f);
		GUILayout.Label(_status, _smallerFont);
	}

	private static string GetCustomData(string customDataFieldValue)
	{
		return (!(customDataFieldValue != _customDataDefaultText)) ? null : customDataFieldValue;
	}

	private static string CreateRequestButtonLabel(string adUnit)
	{
		return (adUnit.Length <= 10) ? adUnit : ("Request " + adUnit.Substring(0, 10) + "...");
	}
}
